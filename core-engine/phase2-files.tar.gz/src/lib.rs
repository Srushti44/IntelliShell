//! IntelliShell Core Library
//! 
//! Production-grade process control and system monitoring for safe command execution.

#![deny(unsafe_code)]
#![warn(missing_docs, clippy::unwrap_used, clippy::expect_used)]

pub mod process;

// Re-export main types
pub use process::{
    ProcessId, ProcessError, ProcessState, KillOptions, KillOutcome,
    kill_process, pause_process, resume_process, renice_process,
};
